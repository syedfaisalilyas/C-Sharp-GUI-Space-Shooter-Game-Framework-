﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace Framework
{
    public partial class StartForm : Form
    {
        private SoundPlayer intro = new SoundPlayer("intro.wav");

        public StartForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Rules form = new Rules();
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WelcomeForm form = new WelcomeForm();
            form.Show();
            this.Hide();
        }

        private void StartForm_Load(object sender, EventArgs e)
        {
            intro.Play();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
