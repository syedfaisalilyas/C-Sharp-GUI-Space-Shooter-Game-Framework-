﻿using Framework;
using PacMan.GameGL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PacManGUI
{
    public partial class NewGame : Form
    {
        private SoundPlayer gameover = new SoundPlayer("Gameover.wav");
      
        public NewGame()
        {
            InitializeComponent();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            return true;
        }
     
   
        private void start_Click(object sender, EventArgs e)
        {
            this.Hide();
            StartForm form = new StartForm();
            form.ShowDialog();
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void NewGame_Load(object sender, EventArgs e)
        {
            gameover.Play();
        }

      
    }
}
