﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Framework
{
    public partial class WelcomeForm : Form
    {
        public WelcomeForm()
        {
            InitializeComponent();
        }

        private void WelcomeForm_Load(object sender, EventArgs e)
        {

        }

        private void start_Click(object sender, EventArgs e)
        {
            PacManGUI.Form1 form = new PacManGUI.Form1(3,100);
            form.ShowDialog();
            this.Hide();
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            PacManGUI.Form1 form = new PacManGUI.Form1(2, 200);
            form.ShowDialog();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PacManGUI.Form1 form = new PacManGUI.Form1(1, 300);
            form.ShowDialog();
            this.Hide();
        }
    }
}
