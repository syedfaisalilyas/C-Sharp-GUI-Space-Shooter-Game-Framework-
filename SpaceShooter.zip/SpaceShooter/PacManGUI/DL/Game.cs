﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace PacMan.GameGL
{
    public class Game
    {
        public static GameObject getBlankGameObject()
        {
            GameObject blankGameObject = new GameObject(GameObjectType.NONE,null);
            return blankGameObject;
        }

        public static GameObject getRewardGameObject()
        {
            GameObject rewardGameObject = new GameObject(GameObjectType.REWARD, Framework.Properties.Resources.pallet);
            return rewardGameObject;
        }
        public static Image getGameObjectImage(char displayCharacter)
        {
            Image img ;
            if (displayCharacter == '|' || displayCharacter == '%')
            {
               return img = Framework.Properties.Resources.vertical;
            }
            if (displayCharacter == ' ')
            {
               return null;
            }

            if (displayCharacter == '#')
            {
               return img = Framework.Properties.Resources.horizontal;
            }

            if (displayCharacter == '.')
            {
               return img = Framework.Properties.Resources.laserBlue09;
            }
            if (displayCharacter == 'S' || displayCharacter == 's') {
            return    img = Framework.Properties.Resources.player;
            }
            if (displayCharacter == 'E' || displayCharacter == 'e')
            {
              return  img = Framework.Properties.Resources.enemy5;
            } 
            if (displayCharacter == 'A' || displayCharacter == 'a') {
             return   img = Framework.Properties.Resources.enemy1;
            }
            if (displayCharacter == 'B' || displayCharacter == 'b')
            {
               return img = Framework.Properties.Resources.enemy2;
            }
            if (displayCharacter == 'C' || displayCharacter == 'c') {
               return img = Framework.Properties.Resources.enemy3;
            } 
            if (displayCharacter == 'D' || displayCharacter == 'd') {
               return img = Framework.Properties.Resources.laserRed01;
            } 
            if (displayCharacter == 'F' || displayCharacter == 'f') {
               return img = Framework.Properties.Resources.laserRed09;
            }
            if (displayCharacter == 'G' || displayCharacter == 'g') {
               return img = Framework.Properties.Resources.Enemy06;
            }
            if (displayCharacter == 'H' || displayCharacter == 'h') {
               return img = Framework.Properties.Resources.Player1_removebg_preview;
            } 
            if (displayCharacter == 'I' || displayCharacter == 'i') {
               return img = Framework.Properties.Resources.laserBlue09;
            }
          

            return null;
        }
    }
}
