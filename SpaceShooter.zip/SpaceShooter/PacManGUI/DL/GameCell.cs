﻿using System.Windows.Forms;
using System.Drawing;
using System;

namespace PacMan.GameGL
{

    public class GameCell
    {
        private int row;
        private int col;
        private GameObject currentGameObject;
        private GameGrid grid;
        private PictureBox pictureBox;
        private const int width = 70;
        private const int height = 70;
        public GameCell(int row, int col, GameGrid grid)
        {
            this.row = row;
            this.col = col;
            this.grid = grid;
            pictureBox = new PictureBox();
            {
                pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox.BackColor = Color.Transparent;
                pictureBox.Left = col * width;
                pictureBox.Top = row * height;
                pictureBox.Size = new Size(width, height);
            }
        }
        public void setGameObject(GameObject gameObject) 
        {
     
            currentGameObject = gameObject;
            pictureBox.Image = gameObject.Image;

        }
        public GameCell nextCell(GameDirection direction)
        {
            int newRow = row;
            int newCol = col;

            if (direction == GameDirection.Left)
            {
                newCol = Math.Max(0, col - 1);
            }
            else if (direction == GameDirection.Right)
            {
                newCol = Math.Min(grid.Cols - 1, col + 1);
            }
            else if (direction == GameDirection.Up)
            {
                newRow = Math.Max(0, row - 1);
            }
            else if (direction == GameDirection.Down)
            {
                newRow = Math.Min(grid.Rows - 1, row + 1);
            }

            GameCell nextCell = grid.getCell(newRow, newCol);
            if (nextCell.CurrentGameObject.GameObjectType != GameObjectType.WALL)
            {
                return nextCell;
            }

            return this; 
        }
    

    public GameObject CurrentGameObject { get => currentGameObject;}
        public PictureBox PictureBox { get => pictureBox; set => pictureBox = value; }
    }
}
