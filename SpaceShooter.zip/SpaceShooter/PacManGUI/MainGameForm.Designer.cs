﻿
namespace PacManGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GameLoop = new System.Windows.Forms.Timer(this.components);
            this.lblLive = new System.Windows.Forms.Label();
            this.Live = new System.Windows.Forms.Label();
            this.Score = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // GameLoop
            // 
            this.GameLoop.Enabled = true;
            this.GameLoop.Interval = 40;
            this.GameLoop.Tick += new System.EventHandler(this.GameLoop_Tick);
            // 
            // lblLive
            // 
            this.lblLive.AutoSize = true;
            this.lblLive.Location = new System.Drawing.Point(2307, 30);
            this.lblLive.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLive.Name = "lblLive";
            this.lblLive.Size = new System.Drawing.Size(60, 20);
            this.lblLive.TabIndex = 0;
            this.lblLive.Text = "Lives:";
            // 
            // Live
            // 
            this.Live.AutoSize = true;
            this.Live.BackColor = System.Drawing.Color.Transparent;
            this.Live.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Live.ForeColor = System.Drawing.Color.DarkRed;
            this.Live.Location = new System.Drawing.Point(6, 5);
            this.Live.Name = "Live";
            this.Live.Size = new System.Drawing.Size(74, 26);
            this.Live.TabIndex = 1;
            this.Live.Text = "Lives:";
            // 
            // Score
            // 
            this.Score.AutoSize = true;
            this.Score.BackColor = System.Drawing.Color.Transparent;
            this.Score.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score.ForeColor = System.Drawing.Color.DarkRed;
            this.Score.Location = new System.Drawing.Point(6, 36);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(78, 26);
            this.Score.TabIndex = 2;
            this.Score.Text = "Score:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::Framework.Properties.Resources.stars_preview;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.Live);
            this.Controls.Add(this.lblLive);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Transparent;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer GameLoop;
        private System.Windows.Forms.Label lblLive;
        private System.Windows.Forms.Label Live;
        private System.Windows.Forms.Label Score;
    }
}

