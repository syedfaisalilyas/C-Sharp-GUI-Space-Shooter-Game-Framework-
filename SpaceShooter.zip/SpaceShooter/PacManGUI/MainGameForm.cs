﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PacMan.GameGL;
using System.Media;
using EZInput;
namespace PacManGUI
{
    public partial class Form1 : Form
    {
        int enemy3currentFireTime;
        int enemy3TimeToGenerateFire;
        int enemy6currentRewardTime;
        int enemy6TimeToGenerateReward;

        NewGame form = new NewGame();
        Framework.GameWin Form = new Framework.GameWin();
        GameGrid grid;
        GameCell startCell;
        GameCell startCellofPlayerbullet;
        GameCell startCellofenemy3bullet;
        GameCell startCellofenemy6bullet;

        Player spaceship;
        EnemyVertical enemy1;
        EnemyVertical enemy2;
        EnemyHorizontal enemy3;
        EnemyVertical enemy4;
        EnemyVertical enemy5;
        EnemyHorizontal enemy6;
        PlayerBullets playerbullet;
        EnemyBullets enemybullet;
        EnemyRewards reward;

        Image playerImage;
        Image enemy1Img;
        Image enemy2Img;
        Image enemy3Img;
        Image enemy4Img;
        Image enemy5Img;
        Image enemy6Img;
        Image playerbulletImg;
        Image enemybulletImg;
        Image rewardImg;

        List<Bullet> PlayerBulletsList = new List<Bullet>();
        List<Bullet> EnemyBulletsList = new List<Bullet>();
        List<Reward> rewards = new List<Reward>();

        int enemypre;
        int speed;
        int winscore;

        private SoundPlayer firingSoundPlayer = new SoundPlayer("shipLaser.wav");
        private SoundPlayer enemyfiringsound = new SoundPlayer("YincaLaser.wav");


        public Form1(int speed,int winscore)
        {
            InitializeComponent();
            this.speed = speed;
            this.winscore = winscore;
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            return true;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            grid = new GameGrid("maze.txt", 12, 22);
            playerImage = Game.getGameObjectImage('S');
            enemy1Img = Game.getGameObjectImage('E');
            enemy2Img = Game.getGameObjectImage('A');
            enemy3Img = Game.getGameObjectImage('B');
            enemy4Img = Game.getGameObjectImage('C');
            enemy5Img = Game.getGameObjectImage('G');
            enemy6Img = Game.getGameObjectImage('H');
            playerbulletImg = Game.getGameObjectImage('D');
            enemybulletImg = Game.getGameObjectImage('F');
            rewardImg = Game.getGameObjectImage('I');
           
            
            startCell = grid.getCell(10,4);
            GameCell startCellofenemy1 = grid.getCell(2,20);
            GameCell startCellofenemy2 = grid.getCell(2,9);
            GameCell startCellofenemy3 = grid.getCell(2,2);
            GameCell startCellofenemy4 = grid.getCell(2,14);
            GameCell startCellofenemy5 = grid.getCell(2,2);
            GameCell startCellofenemy6 = grid.getCell(4,20);
            

            spaceship = new Player(playerImage, startCell,3,0);
            enemy1  = new EnemyVertical(enemy1Img, startCellofenemy1, 3);
            enemy2  = new EnemyVertical(enemy2Img, startCellofenemy2, 3);
            enemy3  = new EnemyHorizontal(enemy3Img, startCellofenemy3, 3);
            enemy4  = new EnemyVertical(enemy4Img, startCellofenemy4, 3);
            enemy5  = new EnemyVertical(enemy5Img, startCellofenemy5, 3);
            enemy6  = new EnemyHorizontal(enemy6Img, startCellofenemy6, 3);
            PrintGrid(grid);

            enemy3TimeToGenerateFire = 40;
            enemy6TimeToGenerateReward = 35;
        }

        void PrintGrid(GameGrid grid)
        {
            for (int x = 0; x < grid.Rows; x++)
            {
               
                for (int y = 0; y < grid.Cols; y++)
                {
                    GameCell cell = grid.getCell(x, y);
                    this.Controls.Add(cell.PictureBox);          
                }

            }
        }

        private void playermovement()
        {
            if (Keyboard.IsKeyPressed(Key.LeftArrow) || Keyboard.IsKeyPressed(Key.A))
            {
                spaceship.move(GameDirection.Left);
            }
            else if (Keyboard.IsKeyPressed(Key.RightArrow) || Keyboard.IsKeyPressed(Key.D))
            {
                spaceship.move(GameDirection.Right);
            }
            else if (Keyboard.IsKeyPressed(Key.UpArrow) || Keyboard.IsKeyPressed(Key.W))
            {
                spaceship.move(GameDirection.Up);
            }
            else if (Keyboard.IsKeyPressed(Key.DownArrow) || Keyboard.IsKeyPressed(Key.S))
            {
                spaceship.move(GameDirection.Down);
            };
        }

        private void GameLoop_Tick(object sender, EventArgs e)
        {
            playermovement();

            startCellofPlayerbullet = spaceship.CurrentCell.nextCell(GameDirection.Up);
            startCellofenemy3bullet = enemy3.CurrentCell;
            startCellofenemy6bullet = enemy6.CurrentCell;

            /*for playerBullets*/

            if (Keyboard.IsKeyPressed(Key.Space))
            {
                firingSoundPlayer.Play();
                playerbullet = new PlayerBullets(playerbulletImg, startCellofPlayerbullet);
                PlayerBulletsList.Add(playerbullet);
            }


            /*Enemy Movements*/
            enemypre++;
            if(enemypre == speed)
            {
            if (enemy1.EnemyLives > 0)
            {
                enemy1.Move(spaceship);
            }
            if (enemy2.EnemyLives > 0)
            {
                enemy2.Move(spaceship);
            }
            if (enemy3.EnemyLives > 0)
            {
                enemy3.Move(spaceship);
            }
            if (enemy4.EnemyLives > 0)
            {
                enemy4.Move(spaceship);
            } 
            if (enemy5.EnemyLives > 0)
            {
                enemy5.Move(spaceship);
            }   
            if (enemy6.EnemyLives > 0)
            {
                enemy6.Move(spaceship);
            }
                enemypre = 0;
            }

            /*Time to fire*/
            enemy3currentFireTime++;
            if (enemy3TimeToGenerateFire == enemy3currentFireTime)
            {
                enemyfiringsound.Play();
                enemybullet = new EnemyBullets(enemybulletImg, startCellofenemy3bullet);
                EnemyBulletsList.Add(enemybullet);
                enemy3currentFireTime = 0;
            }
            
            /*Time For Reward*/
            enemy6currentRewardTime++;
            if (enemy6currentRewardTime == enemy6TimeToGenerateReward)
            {
                reward = new EnemyRewards(rewardImg, startCellofenemy6bullet);
                rewards.Add(reward);
                enemy6currentRewardTime = 0;
            }

            /*Loop for bullets*/
            foreach (Bullet i in PlayerBulletsList)
            {
                if (i != null)
                {
                    i.Move(spaceship);
                 if (i.CurrentCell == enemy1.CurrentCell || i.CurrentCell == enemy2.CurrentCell || i.CurrentCell == enemy3.CurrentCell || i.CurrentCell == enemy4.CurrentCell || i.CurrentCell == enemy5.CurrentCell || i.CurrentCell == enemy6.CurrentCell)
                 {
                    spaceship.Score += 1;
                 }
                }
            } 

            foreach (Bullet i in EnemyBulletsList)
            {
                if (i != null)
                {
                    i.Move(spaceship);
                 if (i.CurrentCell == spaceship.CurrentCell)
                 {
                        if(spaceship.Score >50)
                            spaceship.Score -= 50;
                        if(spaceship.Score>100)
                        {
                            spaceship.Lives--;
                        }
                 }
                }
            }

            /*Loop for Rewards*/
            foreach(Reward i in rewards)
            {
                if(i!= null)
                {
                    i.Move(spaceship);
                    if (i.CurrentCell == spaceship.CurrentCell)
                    {
                        spaceship.Score += 1;
                        if(spaceship.Lives == 1 )
                        {
                            spaceship.Lives++;
                        }
                    }
                }
            }

            /*For Lives and Scores:*/
            if (spaceship.Lives <= 0)
            {
                GameLoop.Enabled = false;
                form.Show();
                this.Hide();
            }

            if(spaceship.Score>=winscore)
            {
                GameLoop.Enabled = false;
                Form.Show();
                this.Hide();
            }
            Live.Text = "Lives: " + spaceship.Lives.ToString();
            Score.Text = "Score: " + spaceship.Score.ToString();
        }
    }
}
