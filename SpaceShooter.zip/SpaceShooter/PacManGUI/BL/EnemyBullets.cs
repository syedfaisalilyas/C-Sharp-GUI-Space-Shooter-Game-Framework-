﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacMan.GameGL
{
    class EnemyBullets : Bullet
    {
        public GameDirection direction = GameDirection.Down;
        public EnemyBullets(Image displayChar, GameCell start) : base(displayChar, start)
        {
            this.CurrentCell = start;
        }

        public override GameCell Move(Player player)
        {
            GameCell CurrentCell = this.CurrentCell;
            GameCell previous = CurrentCell;
            GameCell nextCell = CurrentCell.nextCell(direction);


            this.CurrentCell = nextCell;
            if (CurrentCell == nextCell)
            {
                CurrentCell.setGameObject(Game.getBlankGameObject());
            }

            if (CurrentCell != nextCell && (nextCell.CurrentGameObject?.GameObjectType != GameObjectType.WALL))
            {
                CurrentCell.setGameObject(Game.getBlankGameObject());
            }
           
            return nextCell;
        }

    }
}
