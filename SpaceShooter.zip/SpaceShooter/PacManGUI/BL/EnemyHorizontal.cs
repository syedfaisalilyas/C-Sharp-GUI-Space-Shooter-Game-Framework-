﻿using PacMan.GameGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using PacManGUI;
using System.Media;

namespace PacMan.GameGL
{
        class EnemyHorizontal : Enemy
        {
        private SoundPlayer explosion = new SoundPlayer("explosion.wav");
        public GameDirection direction = GameDirection.Left;
            private int enemylives;
            public EnemyHorizontal(Image displayChar, GameCell start,int lives) : base(displayChar, start) { this.CurrentCell = start;this.EnemyLives = lives; }

        public int EnemyLives { get => enemylives; set => enemylives = value; }

        public override void checkdirection()
            {
                if (direction == GameDirection.Left)
                {
                    direction = GameDirection.Right;
                }
                else if (direction == GameDirection.Right)
                {
                    direction = GameDirection.Left;
                }
            }
            public override GameCell Move(Player player)
            {
                GameCell CurrentCell = this.CurrentCell;
                GameCell nextCell = CurrentCell.nextCell(direction);
                if (nextCell.CurrentGameObject.GameObjectType == GameObjectType.PLAYER)
                {
                   
                        CurrentCell.setGameObject(Game.getBlankGameObject());
                explosion.Play();
                    player.Lives--;
                }
                this.CurrentCell = nextCell;
                if (CurrentCell == nextCell)
                {
                    checkdirection();
                }
                if (CurrentCell != nextCell&&(nextCell.CurrentGameObject?.GameObjectType!=GameObjectType.WALL))
                {
                    CurrentCell.setGameObject(Game.getBlankGameObject());
                }
                return nextCell;
            }
    }
}

