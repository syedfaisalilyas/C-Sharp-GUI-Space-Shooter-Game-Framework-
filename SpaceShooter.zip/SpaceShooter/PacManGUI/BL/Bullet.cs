﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacMan.GameGL
{
    abstract class Bullet:GameObject
    {
        public Bullet(Image image, GameCell startCell) : base(GameObjectType.ENEMY, image)
        {
            startCell.PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CurrentCell = startCell;
        }
        public abstract GameCell Move(Player player);
    }
}
